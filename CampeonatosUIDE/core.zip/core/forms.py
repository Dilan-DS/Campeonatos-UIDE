from django import forms
from .models import Carrera, Usuario, Deporte, Arbitro, Campeonato, Equipo, Jugador, Partido, Transmision, Pago, CodigoQR, TipoCampeonato, ImagenGaleria, Noticia, Testimonio, Suspension
from django.contrib.auth.forms import UserCreationForm

class EquipoForm(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = ['nombre', 'campeonato', 'carrera', 'logo', 'delegado', 'aprobado']

class PagoForm(forms.ModelForm):
    class Meta:
        model = Pago
        fields = ['metodo', 'monto', 'nombre_titular', 'fecha_pago', 'codigo_qr', 'comprobante_pago']
        widgets = {
            'metodo': forms.Select(attrs={'class': 'input'}),
            'monto': forms.NumberInput(attrs={'class': 'input'}),
            'nombre_titular': forms.TextInput(attrs={'class': 'input'}),
            'fecha_pago': forms.DateTimeInput(attrs={'class': 'input', 'type': 'datetime-local'}),
            'codigo_qr': forms.Select(attrs={'class': 'select'}),
            'comprobante_pago': forms.FileInput(attrs={'class': 'file-input'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['codigo_qr'].queryset = CodigoQR.objects.all()
        self.fields['comprobante_pago'].required = False
        self.fields['codigo_qr'].required = False
        self.fields['nombre_titular'].required = False

    def clean(self):
        cleaned_data = super().clean()
        metodo = cleaned_data.get('metodo')

        if metodo == 'TRANSFERENCIA':
            if not cleaned_data.get('comprobante_pago'):
                self.add_error('comprobante_pago', 'El comprobante es obligatorio para transferencias.')
            if not cleaned_data.get('codigo_qr'):
                self.add_error('codigo_qr', 'Debe seleccionar un banco para la transferencia.')
            if not cleaned_data.get('nombre_titular'):
                self.add_error('nombre_titular', 'El nombre del titular es obligatorio para transferencias.')
        
        return cleaned_data

class RegistroUsuarioPublicoForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = Usuario
        fields = ('username', 'email')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.rol = 'JUGADOR'
        if commit:
            user.save()
        return user

class CampeonatoForm(forms.ModelForm):
    class Meta:
        model = Campeonato
        fields = ['nombre', 'descripcion', 'fecha_inicio', 'fecha_fin', 'estado', 'tipo_campeonato', 'deporte']

class PartidoForm(forms.ModelForm):
    class Meta:
        model = Partido
        fields = ['campeonato', 'equipo_local', 'equipo_visitante', 'fecha', 'hora', 'lugar', 'arbitro', 'estado', 'resultado_local', 'resultado_visitante']

class ArbitroForm(forms.ModelForm):
    class Meta:
        model = Arbitro
        fields = ['usuario', 'experiencia', 'deportes', 'contacto', 'estado']

class DeporteForm(forms.ModelForm):
    class Meta:
        model = Deporte
        fields = ['nombre', 'descripcion']

class TipoCampeonatoForm(forms.ModelForm):
    class Meta:
        model = TipoCampeonato
        fields = ['nombre', 'descripcion', 'deportes_permitidos']

class TransmisionForm(forms.ModelForm):
    class Meta:
        model = Transmision
        fields = ['campeonato', 'partido', 'enlace', 'descripcion', 'activa']

class SuspensionForm(forms.ModelForm):
    class Meta:
        model = Suspension
        fields = ['jugador', 'fecha_inicio', 'fecha_fin', 'motivo']

class CodigoQRForm(forms.ModelForm):
    class Meta:
        model = CodigoQR
        fields = ['banco', 'imagen_qr', 'descripcion']

class ImagenGaleriaForm(forms.ModelForm):
    class Meta:
        model = ImagenGaleria
        fields = ['titulo', 'imagen', 'descripcion']

class NoticiaForm(forms.ModelForm):
    class Meta:
        model = Noticia
        fields = ['titulo', 'contenido', 'imagen']

class TestimonioForm(forms.ModelForm):
    class Meta:
        model = Testimonio
        fields = ['autor', 'contenido', 'foto']

class JugadorForm(forms.ModelForm):
    class Meta:
        model = Jugador
        fields = ['equipo', 'usuario', 'numero_camiseta', 'edad']

class CarreraForm(forms.ModelForm):
    class Meta:
        model = Carrera
        fields = ['nombre']

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['username', 'first_name', 'last_name', 'email', 'rol', 'carrera']
