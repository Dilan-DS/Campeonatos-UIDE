from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def estadisticas_futbol(request):
    return render(request, 'estadisticas/futbol.html')

@login_required
def estadisticas_basquet(request):
    return render(request, 'estadisticas/basquet.html')

@login_required
def estadisticas_ecuaboly(request):
    return render(request, 'estadisticas/ecuaboly.html')

@login_required
def estadisticas_ajedrez(request):
    return render(request, 'estadisticas/ajedrez.html')

@login_required
def estadisticas_tenis(request):
    return render(request, 'estadisticas/tenis.html')

@login_required
def estadisticas_pingpong(request):
    return render(request, 'estadisticas/pingpong.html')

@login_required
def estadisticas_futbolin(request):
    return render(request, 'estadisticas/futbolin.html')

@login_required
def estadisticas_videojuegos(request):
    return render(request, 'estadisticas/videojuegos.html')

@login_required
def mis_estadisticas(request):
    return render(request, 'estadisticas/mis_estadisticas.html')

@login_required
def export_estadisticas_futbol_pdf(request):
    pass

@login_required
def export_estadisticas_futbol_excel(request):
    pass

@login_required
def export_estadisticas_basquet_pdf(request):
    pass

@login_required
def export_estadisticas_basquet_excel(request):
    pass

@login_required
def export_estadisticas_ajedrez_pdf(request):
    pass

@login_required
def export_estadisticas_ajedrez_excel(request):
    pass

@login_required
def export_estadisticas_ecuaboly_pdf(request):
    pass

@login_required
def export_estadisticas_ecuaboly_excel(request):
    pass

@login_required
def export_estadisticas_futbolin_pdf(request):
    pass

@login_required
def export_estadisticas_futbolin_excel(request):
    pass

@login_required
def export_estadisticas_pingpong_pdf(request):
    pass

@login_required
def export_estadisticas_pingpong_excel(request):
    pass

@login_required
def export_estadisticas_tenis_pdf(request):
    pass

@login_required
def export_estadisticas_tenis_excel(request):
    pass

@login_required
def export_estadisticas_videojuegos_pdf(request):
    pass

@login_required
def export_estadisticas_videojuegos_excel(request):
    pass
