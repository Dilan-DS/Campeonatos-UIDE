from django.shortcuts import render, redirect
from ..models import Suspension
from ..forms import SuspensionForm
from django.contrib.auth.decorators import login_required

@login_required
def listar_suspensiones(request):
    suspensiones = Suspension.objects.all()
    return render(request, 'suspension/listar.html', {'suspensiones': suspensiones})

@login_required
def registrar_suspension(request):
    if request.method == 'POST':
        form = SuspensionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_suspensiones')
    else:
        form = SuspensionForm()
    return render(request, 'suspension/registrar.html', {'form': form})

@login_required
def detalle_suspension(request, suspension_id):
    suspension = Suspension.objects.get(id=suspension_id)
    return render(request, 'suspension/detalle.html', {'suspension': suspension})
