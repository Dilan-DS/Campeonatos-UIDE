from django.shortcuts import render, redirect
from django.views import View
from ..models import Campeonato, Partido
from ..forms import CampeonatoForm, PartidoForm
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListarCampeonatos(View):
    def get(self, request, *args, **kwargs):
        campeonatos = Campeonato.objects.all()
        return render(request, 'campeonato/listar.html', {'campeonatos': campeonatos})

@method_decorator(login_required, name='dispatch')
class CrearCampeonato(View):
    def get(self, request, *args, **kwargs):
        form = CampeonatoForm()
        return render(request, 'campeonato/crear.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = CampeonatoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_campeonatos')
        return render(request, 'campeonato/crear.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class DetalleCampeonato(View):
    def get(self, request, *args, **kwargs):
        campeonato = Campeonato.objects.get(id=kwargs['id'])
        return render(request, 'campeonato/detalle_campeonato.html', {'campeonato': campeonato})

@method_decorator(login_required, name='dispatch')
class EditarCampeonato(View):
    def get(self, request, *args, **kwargs):
        campeonato = Campeonato.objects.get(id=kwargs['id'])
        form = CampeonatoForm(instance=campeonato)
        return render(request, 'campeonato/editar_campeonato.html', {'form': form})
    def post(self, request, *args, **kwargs):
        campeonato = Campeonato.objects.get(id=kwargs['id'])
        form = CampeonatoForm(request.POST, instance=campeonato)
        if form.is_valid():
            form.save()
            return redirect('listar_campeonatos')
        return render(request, 'campeonato/editar_campeonato.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EliminarCampeonato(View):
    def get(self, request, *args, **kwargs):
        campeonato = Campeonato.objects.get(id=kwargs['id'])
        return render(request, 'campeonato/eliminar.html', {'campeonato': campeonato})
    def post(self, request, *args, **kwargs):
        campeonato = Campeonato.objects.get(id=kwargs['id'])
        campeonato.delete()
        return redirect('listar_campeonatos')

@method_decorator(login_required, name='dispatch')
class FixtureCampeonato(View):
    def get(self, request, *args, **kwargs):
        partidos = Partido.objects.filter(campeonato_id=kwargs['id'])
        return render(request, 'campeonato/fixture.html', {'partidos': partidos})

@method_decorator(login_required, name='dispatch')
class TablaPosiciones(View):
    def get(self, request, *args, **kwargs):
        campeonato = Campeonato.objects.get(id=kwargs['campeonato_id'])
        return render(request, 'campeonato/tabla_posiciones.html', {'campeonato': campeonato})

@method_decorator(login_required, name='dispatch')
class GenerarCalendario(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'campeonato/generar_calendario.html')

@login_required
def tabla_estadisticas(request, campeonato_id):
    return render(request, 'campeonato/tabla_estadisticas.html')

@login_required
def export_tabla_posiciones_pdf(request, campeonato_id):
    pass

@login_required
def export_tabla_posiciones_excel(request, campeonato_id):
    pass

@method_decorator(login_required, name='dispatch')
class CampeonatosPublicos(View):
     def get(self, request, *args, **kwargs):
        campeonatos = Campeonato.objects.filter(es_publico='SI')
        return render(request, 'campeonato/campeonatos_publicos.html', {'campeonatos': campeonatos})

@login_required
def obtener_tipos_campeonato_ajax(request):
    pass