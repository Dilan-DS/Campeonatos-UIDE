from django.shortcuts import render, redirect
from django.views import View
from ..models import *
from ..forms import *
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListarTransmisionView(View):
    def get(self, request, *args, **kwargs):
        transmisiones = Transmision.objects.all()
        return render(request, 'transmision/listar.html', {'transmisiones': transmisiones})

@method_decorator(login_required, name='dispatch')
class CrearTransmisionView(View):
    def get(self, request, *args, **kwargs):
        form = TransmisionForm()
        return render(request, 'transmision/crear.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = TransmisionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_transmisiones')
        return render(request, 'transmision/crear.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class DetalleTransmisionView(View):
    def get(self, request, *args, **kwargs):
        transmision = Transmision.objects.get(id=kwargs['id'])
        return render(request, 'transmision/detalle.html', {'transmision': transmision})

@method_decorator(login_required, name='dispatch')
class EditarTransmisionView(View):
    def get(self, request, *args, **kwargs):
        transmision = Transmision.objects.get(id=kwargs['id'])
        form = TransmisionForm(instance=transmision)
        return render(request, 'transmision/editar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        transmision = Transmision.objects.get(id=kwargs['id'])
        form = TransmisionForm(request.POST, instance=transmision)
        if form.is_valid():
            form.save()
            return redirect('listar_transmisiones')
        return render(request, 'transmision/editar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EliminarTransmisionView(View):
    def get(self, request, *args, **kwargs):
        transmision = Transmision.objects.get(id=kwargs['id'])
        return render(request, 'transmision/eliminar.html', {'transmision': transmision})
    def post(self, request, *args, **kwargs):
        transmision = Transmision.objects.get(id=kwargs['id'])
        transmision.delete()
        return redirect('listar_transmisiones')