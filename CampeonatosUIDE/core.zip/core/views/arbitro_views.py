from django.shortcuts import render, redirect
from django.views import View
from ..models import Arbitro
from ..forms import ArbitroForm
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class listar_arbitros(View):
    def get(self, request, *args, **kwargs):
        arbitros = Arbitro.objects.all()
        return render(request, 'arbitro/listar.html', {'arbitros': arbitros})

@method_decorator(login_required, name='dispatch')
class registrar_arbitro(View):
    def get(self, request, *args, **kwargs):
        form = ArbitroForm()
        return render(request, 'arbitro/registrar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = ArbitroForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_arbitros')
        return render(request, 'arbitro/registrar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class detalle_arbitro(View):
    def get(self, request, *args, **kwargs):
        arbitro = Arbitro.objects.get(id=kwargs['id'])
        return render(request, 'arbitro/detalle.html', {'arbitro': arbitro})

@method_decorator(login_required, name='dispatch')
class editar_arbitro(View):
    def get(self, request, *args, **kwargs):
        arbitro = Arbitro.objects.get(id=kwargs['id'])
        form = ArbitroForm(instance=arbitro)
        return render(request, 'arbitro/editar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        arbitro = Arbitro.objects.get(id=kwargs['id'])
        form = ArbitroForm(request.POST, instance=arbitro)
        if form.is_valid():
            form.save()
            return redirect('listar_arbitros')
        return render(request, 'arbitro/editar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class eliminar_arbitro(View):
    def get(self, request, *args, **kwargs):
        arbitro = Arbitro.objects.get(id=kwargs['id'])
        return render(request, 'arbitro/eliminar.html', {'arbitro': arbitro})
    def post(self, request, *args, **kwargs):
        arbitro = Arbitro.objects.get(id=kwargs['id'])
        arbitro.delete()
        return redirect('listar_arbitros')

@method_decorator(login_required, name='dispatch')
class HistorialArbitrosView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'arbitro/historial_arbitros.html')

@method_decorator(login_required, name='dispatch')
class VistaPartidosArbitro(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'arbitro/mis_partidos.html')