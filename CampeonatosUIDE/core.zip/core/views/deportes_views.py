from django.shortcuts import render, redirect
from django.views import View
from ..models import *
from ..forms import *
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListarDeportesView(View):
    def get(self, request, *args, **kwargs):
        deportes = Deporte.objects.all()
        return render(request, 'deporte/listar.html', {'deportes': deportes})

@method_decorator(login_required, name='dispatch')
class RegistrarDeporteView(View):
    def get(self, request, *args, **kwargs):
        form = DeporteForm()
        return render(request, 'deporte/registrar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = DeporteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_deportes')
        return render(request, 'deporte/registrar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EditarDeporteView(View):
    def get(self, request, *args, **kwargs):
        deporte = Deporte.objects.get(id=kwargs['id'])
        form = DeporteForm(instance=deporte)
        return render(request, 'deporte/editar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        deporte = Deporte.objects.get(id=kwargs['id'])
        form = DeporteForm(request.POST, instance=deporte)
        if form.is_valid():
            form.save()
            return redirect('listar_deportes')
        return render(request, 'deporte/editar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EliminarDeporteView(View):
    def get(self, request, *args, **kwargs):
        deporte = Deporte.objects.get(id=kwargs['id'])
        return render(request, 'deporte/eliminar.html', {'deporte': deporte})
    def post(self, request, *args, **kwargs):
        deporte = Deporte.objects.get(id=kwargs['id'])
        deporte.delete()
        return redirect('listar_deportes')