from django.shortcuts import render, redirect
from django.views import View
from ..models import *
from ..forms import *
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListaTiposCampeonatoView(View):
    def get(self, request, *args, **kwargs):
        tipos = TipoCampeonato.objects.all()
        return render(request, 'tipo_campeonato/listar.html', {'tipos': tipos})

@method_decorator(login_required, name='dispatch')
class RegistrarTipoCampeonatoView(View):
    def get(self, request, *args, **kwargs):
        form = TipoCampeonatoForm()
        return render(request, 'tipo_campeonato/registrar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = TipoCampeonatoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_tipos_campeonato')
        return render(request, 'tipo_campeonato/registrar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EditarTipoCampeonatoView(View):
    def get(self, request, *args, **kwargs):
        tipo = TipoCampeonato.objects.get(id=kwargs['id'])
        form = TipoCampeonatoForm(instance=tipo)
        return render(request, 'tipo_campeonato/editar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        tipo = TipoCampeonato.objects.get(id=kwargs['id'])
        form = TipoCampeonatoForm(request.POST, instance=tipo)
        if form.is_valid():
            form.save()
            return redirect('listar_tipos_campeonato')
        return render(request, 'tipo_campeonato/editar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EliminarTipoCampeonatoView(View):
    def get(self, request, *args, **kwargs):
        tipo = TipoCampeonato.objects.get(id=kwargs['id'])
        return render(request, 'tipo_campeonato/eliminar.html', {'tipo': tipo})
    def post(self, request, *args, **kwargs):
        tipo = TipoCampeonato.objects.get(id=kwargs['id'])
        tipo.delete()
        return redirect('listar_tipos_campeonato')