from django.shortcuts import render, redirect
from ..models import Partido
from ..forms import PartidoForm
from django.contrib.auth.decorators import login_required

@login_required
def listar_partidos(request):
    partidos = Partido.objects.all()
    return render(request, 'partido/listar.html', {'partidos': partidos})

@login_required
def registrar_partido(request):
    if request.method == 'POST':
        form = PartidoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_partidos')
    else:
        form = PartidoForm()
    return render(request, 'partido/registrar.html', {'form': form})

@login_required
def detalle_partido(request, partido_id):
    partido = Partido.objects.get(id=partido_id)
    return render(request, 'partido/detalle.html', {'partido': partido})

@login_required
def ver_calendario_completo(request):
    partidos = Partido.objects.all()
    return render(request, 'partido/calendario.html', {'partidos': partidos})