from django.shortcuts import render, redirect
from django.views import View
from ..models import *
from ..forms import *
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListarCodigosQRView(View):
    def get(self, request, *args, **kwargs):
        codigos = CodigoQR.objects.all()
        return render(request, 'codigoqr/listar.html', {'codigos': codigos})

@method_decorator(login_required, name='dispatch')
class RegistrarCodigoQRView(View):
    def get(self, request, *args, **kwargs):
        form = CodigoQRForm()
        return render(request, 'codigoqr/registrar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = CodigoQRForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('listar_codigos_qr')
        return render(request, 'codigoqr/registrar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EditarCodigoQRView(View):
    def get(self, request, *args, **kwargs):
        codigo = CodigoQR.objects.get(pk=kwargs['pk'])
        form = CodigoQRForm(instance=codigo)
        return render(request, 'codigoqr/editar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        codigo = CodigoQR.objects.get(pk=kwargs['pk'])
        form = CodigoQRForm(request.POST, request.FILES, instance=codigo)
        if form.is_valid():
            form.save()
            return redirect('listar_codigos_qr')
        return render(request, 'codigoqr/editar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class DetalleCodigoQRView(View):
    def get(self, request, *args, **kwargs):
        codigo = CodigoQR.objects.get(pk=kwargs['pk'])
        return render(request, 'codigoqr/detalle.html', {'codigo': codigo})

@method_decorator(login_required, name='dispatch')
class EliminarCodigoQRView(View):
    def get(self, request, *args, **kwargs):
        codigo = CodigoQR.objects.get(pk=kwargs['pk'])
        return render(request, 'codigoqr/eliminar.html', {'codigo': codigo})
    def post(self, request, *args, **kwargs):
        codigo = CodigoQR.objects.get(pk=kwargs['pk'])
        codigo.delete()
        return redirect('listar_codigos_qr')