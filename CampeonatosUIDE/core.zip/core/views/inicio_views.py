from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from ..models import Partido, Campeonato

@login_required
def vista_inicio(request):
    if request.user.rol == 'ADMIN':
        return render(request, 'admin_panel/dashboard.html')
    elif request.user.rol == 'DELEGADO':
        return render(request, 'delegado/dashboard.html')
    elif request.user.rol == 'JUGADOR':
        return render(request, 'jugador/dashboard.html')
    else:
        return render(request, 'publica/inicio.html')

def inicio_publico(request):
    return render(request, 'publica/inicio.html')

class VistaPublicaPartidos:
    def as_view(self):
        def view(request):
            partidos = Partido.objects.all()
            return render(request, 'publica/partidos.html', {'partidos': partidos})
        return view

def resultados_publicos(request):
    campeonatos = Campeonato.objects.filter(estado='FINALIZADO')
    return render(request, 'publica/resultados.html', {'campeonatos': campeonatos})