from django.shortcuts import render, redirect
from django.views import View
from ..models import *
from ..forms import *
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListarPagosAdminView(View):
    def get(self, request, *args, **kwargs):
        pagos = Pago.objects.all()
        return render(request, 'admin_panel/listar_pagos.html', {'pagos': pagos})

@method_decorator(login_required, name='dispatch')
class RegistrarPagoAdminView(View):
    def get(self, request, *args, **kwargs):
        form = PagoForm()
        return render(request, 'admin_panel/registrar_pago.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = PagoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_pagos_admin')
        return render(request, 'admin_panel/registrar_pago.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EditarPagoAdminView(View):
    def get(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        form = PagoForm(instance=pago)
        return render(request, 'admin_panel/editar_pago.html', {'form': form})
    def post(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        form = PagoForm(request.POST, instance=pago)
        if form.is_valid():
            form.save()
            return redirect('listar_pagos_admin')
        return render(request, 'admin_panel/editar_pago.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EliminarPagoAdminView(View):
    def get(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        return render(request, 'admin_panel/eliminar_pago.html', {'pago': pago})
    def post(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        pago.delete()
        return redirect('listar_pagos_admin')

@method_decorator(login_required, name='dispatch')
class DetallePagoAdminView(View):
    def get(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        return render(request, 'admin_panel/detalle_pago.html', {'pago': pago})

@method_decorator(login_required, name='dispatch')
class AprobarPagoAdminView(View):
    def get(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        pago.estado = 'APROBADO'
        pago.save()
        return redirect('listar_pagos_admin')

@method_decorator(login_required, name='dispatch')
class RechazarPagoAdminView(View):
    def get(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        pago.estado = 'RECHAZADO'
        pago.save()
        return redirect('listar_pagos_admin')

@method_decorator(login_required, name='dispatch')
class RegistrarPagoDelegadoView(View):
    def get(self, request, *args, **kwargs):
        form = PagoForm()
        return render(request, 'delegado/registrar_pago.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class DetallePagoDelegadoView(View):
    def get(self, request, *args, **kwargs):
        pago = Pago.objects.filter(equipo__delegado=request.user).first()
        return render(request, 'delegado/detalle_pago.html', {'pago': pago})

@method_decorator(login_required, name='dispatch')
class EliminarPagoDelegadoView(View):
    def get(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        return render(request, 'delegado/eliminar_pago.html', {'pago': pago})
    def post(self, request, *args, **kwargs):
        pago = Pago.objects.get(pk=kwargs['pk'])
        pago.delete()
        return redirect('detalle_pago_delegado')
