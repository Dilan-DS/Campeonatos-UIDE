from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from ..models import Equipo, Pago, CodigoQR
from ..forms import PagoForm
from ..decorators import role_required

@method_decorator(login_required, name='dispatch')
@method_decorator(role_required('DELEGADO'), name='dispatch')
class DelegadoDashboardView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'delegado/dashboard.html')

@login_required
@role_required('DELEGADO')
def registrar_pago(request):
    try:
        equipo = Equipo.objects.get(delegado=request.user)
    except Equipo.DoesNotExist:
        return render(request, 'delegado/sin_equipo.html')

    if Pago.objects.filter(equipo=equipo).exists():
        return redirect('ver_estado_pago')

    if request.method == 'POST':
        form = PagoForm(request.POST, request.FILES)
        if form.is_valid():
            pago = form.save(commit=False)
            pago.equipo = equipo
            pago.save()
            return redirect('ver_estado_pago')
    else:
        form = PagoForm()
    
    codigos_qr = CodigoQR.objects.all()
    qr_data = {qr.id: qr.imagen_qr.url for qr in codigos_qr}

    return render(request, 'delegado/registrar_pago.html', {
        'form': form,
        'equipo': equipo,
        'codigos_qr': codigos_qr,
        'qr_data': qr_data,
    })

@login_required
@role_required('DELEGADO')
def ver_estado_pago(request):
    try:
        equipo = Equipo.objects.get(delegado=request.user)
        pago = Pago.objects.get(equipo=equipo)
    except (Equipo.DoesNotExist, Pago.DoesNotExist):
        return redirect('registrar_pago')

    return render(request, 'delegado/pago_existente.html', {'pago': pago})

@method_decorator(login_required, name='dispatch')
class VistaPartidosDelegado(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'delegado/mis_partidos.html')