from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from ..models import Pago, Usuario, Carrera
from ..decorators import role_required
from ..forms import UsuarioForm, CarreraForm
from django.http import HttpResponse

def es_admin(user):
    return user.is_authenticated and user.rol == 'ADMIN'

@user_passes_test(es_admin)
def admin_dashboard(request):
    return render(request, 'admin_panel/dashboard.html')

@user_passes_test(es_admin)
def crear_usuario_admin(request):
    if request.method == 'POST':
        form = UsuarioForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_usuarios')
    else:
        form = UsuarioForm()
    return render(request, 'admin_panel/crear_usuario.html', {'form': form})

@user_passes_test(es_admin)
def listar_usuarios(request):
    usuarios = Usuario.objects.all()
    return render(request, 'admin_panel/listar_usuarios.html', {'usuarios': usuarios})

@user_passes_test(es_admin)
def editar_usuario(request, usuario_id):
    usuario = get_object_or_404(Usuario, id=usuario_id)
    if request.method == 'POST':
        form = UsuarioForm(request.POST, instance=usuario)
        if form.is_valid():
            form.save()
            return redirect('listar_usuarios')
    else:
        form = UsuarioForm(instance=usuario)
    return render(request, 'admin_panel/editar_usuario.html', {'form': form})

@user_passes_test(es_admin)
def eliminar_usuario(request, usuario_id):
    usuario = get_object_or_404(Usuario, id=usuario_id)
    if request.method == 'POST':
        usuario.delete()
        return redirect('listar_usuarios')
    return render(request, 'admin_panel/eliminar_usuario.html', {'usuario': usuario})

@user_passes_test(es_admin)
def registrar_delegado_admin(request):
    if request.method == 'POST':
        form = UsuarioForm(request.POST)
        if form.is_valid():
            usuario = form.save(commit=False)
            usuario.rol = 'DELEGADO'
            usuario.save()
            return redirect('gestion_delegados')
    else:
        form = UsuarioForm()
    return render(request, 'admin_panel/registrar_delegado.html', {'form': form})

@user_passes_test(es_admin)
def listar_delegados(request):
    delegados = Usuario.objects.filter(rol='DELEGADO')
    return render(request, 'admin_panel/listar_delegados.html', {'delegados': delegados})

@user_passes_test(es_admin)
def eliminar_delegado(request, delegado_id):
    delegado = get_object_or_404(Usuario, id=delegado_id)
    if request.method == 'POST':
        delegado.delete()
        return redirect('gestion_delegados')
    return render(request, 'admin_panel/eliminar_delegado.html', {'delegado': delegado})

@user_passes_test(es_admin)
def registrar_carrera(request):
    if request.method == 'POST':
        form = CarreraForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_carreras')
    else:
        form = CarreraForm()
    return render(request, 'admin_panel/registrar_carrera.html', {'form': form})

@user_passes_test(es_admin)
def listar_carreras(request):
    carreras = Carrera.objects.all()
    return render(request, 'admin_panel/listar_carreras.html', {'carreras': carreras})

@user_passes_test(es_admin)
def eliminar_carrera(request, id):
    carrera = get_object_or_404(Carrera, id=id)
    if request.method == 'POST':
        carrera.delete()
        return redirect('listar_carreras')
    return render(request, 'admin_panel/eliminar_carrera.html', {'carrera': carrera})

@user_passes_test(es_admin)
def exportar_estadisticas_pdf(request):
    return HttpResponse("Aquí se exportarían las estadísticas en PDF.")

@user_passes_test(es_admin)
def exportar_estadisticas_excel(request):
    return HttpResponse("Aquí se exportarían las estadísticas en Excel.")

def es_admin_o_delegado(user):
    return user.is_authenticated and (user.rol == 'ADMIN' or user.rol == 'DELEGADO')

@login_required
@role_required('ADMIN')
def listar_pagos_pendientes(request):
    pagos = Pago.objects.filter(estado='PENDIENTE')
    return render(request, 'admin_panel/listar_pagos_pendientes.html', {'pagos': pagos})

@login_required
@role_required('ADMIN')
def aceptar_pago(request, pago_id):
    pago = get_object_or_404(Pago, id=pago_id)
    pago.estado = 'APROBADO'
    pago.save()
    return redirect('listar_pagos_pendientes')

@login_required
@role_required('ADMIN')
def rechazar_pago(request, pago_id):
    pago = get_object_or_404(Pago, id=pago_id)
    if request.method == 'POST':
        observacion = request.POST.get('observacion', '')
        pago.estado = 'RECHAZADO'
        pago.observacion_admin = observacion
        pago.save()
        return redirect('listar_pagos_pendientes')
    return render(request, 'admin_panel/rechazar_pago.html', {'pago': pago})

@user_passes_test(es_admin_o_delegado)
def vista_protegida_ejemplo(request):
    # Tu lógica de vista aquí
    return render(request, 'admin_panel/vista_protegida.html')
