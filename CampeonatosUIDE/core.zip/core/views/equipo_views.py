from django.shortcuts import render, redirect
from ..models import Equipo, Pago
from ..forms import EquipoForm
from django.contrib.auth.decorators import login_required

@login_required
def listar_equipos(request):
    equipos = Equipo.objects.all()
    return render(request, 'equipo/listar.html', {'equipos': equipos})

@login_required
def registrar_equipo(request):
    if request.method == 'POST':
        form = EquipoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('listar_equipos')
    else:
        form = EquipoForm()
    return render(request, 'equipo/registrar.html', {'form': form})

@login_required
def detalle_equipo(request, id):
    equipo = Equipo.objects.get(id=id)
    return render(request, 'equipo/detalle.html', {'equipo': equipo})

@login_required
def editar_equipo(request, id):
    equipo = Equipo.objects.get(id=id)
    if request.method == 'POST':
        form = EquipoForm(request.POST, request.FILES, instance=equipo)
        if form.is_valid():
            form.save()
            return redirect('listar_equipos')
    else:
        form = EquipoForm(instance=equipo)
    return render(request, 'equipo/editar.html', {'form': form})

@login_required
def eliminar_equipo(request, id):
    equipo = Equipo.objects.get(id=id)
    if request.method == 'POST':
        equipo.delete()
        return redirect('listar_equipos')
    return render(request, 'equipo/eliminar.html', {'equipo': equipo})

@login_required
def pago_equipo(request, id):
    pago = Pago.objects.filter(equipo_id=id).first()
    return render(request, 'pago/detalle.html', {'pago': pago})

@login_required
def jugadores_equipo(request, id):
    equipo = Equipo.objects.get(id=id)
    return render(request, 'equipo/jugadores.html', {'equipo': equipo})