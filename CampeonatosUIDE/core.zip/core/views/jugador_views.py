from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def jugador_dashboard(request):
    return render(request, 'jugador/dashboard.html')

@login_required
def ver_estadisticas_jugador(request, jugador_id):
    return render(request, 'jugador/estadisticas.html')

class VistaPartidosJugador:
    def as_view(self):
        def view(request):
            return render(request, 'jugador/mis_partidos.html')
        return view