from django.shortcuts import render, redirect
from django.views import View
from ..models import *
from ..forms import *
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListarImagenGaleria(View):
    def get(self, request, *args, **kwargs):
        imagenes = ImagenGaleria.objects.all()
        return render(request, 'galeria/listar.html', {'imagenes': imagenes})

@method_decorator(login_required, name='dispatch')
class RegistrarImagenGaleria(View):
    def get(self, request, *args, **kwargs):
        form = ImagenGaleriaForm()
        return render(request, 'galeria/registrar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = ImagenGaleriaForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('listar_imagenes_galeria')
        return render(request, 'galeria/registrar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EditarImagenGaleria(View):
    def get(self, request, *args, **kwargs):
        imagen = ImagenGaleria.objects.get(id=kwargs['id'])
        form = ImagenGaleriaForm(instance=imagen)
        return render(request, 'galeria/editar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        imagen = ImagenGaleria.objects.get(id=kwargs['id'])
        form = ImagenGaleriaForm(request.POST, request.FILES, instance=imagen)
        if form.is_valid():
            form.save()
            return redirect('listar_imagenes_galeria')
        return render(request, 'galeria/editar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EliminarImagenGaleria(View):
    def get(self, request, *args, **kwargs):
        imagen = ImagenGaleria.objects.get(id=kwargs['id'])
        return render(request, 'galeria/eliminar.html', {'imagen': imagen})
    def post(self, request, *args, **kwargs):
        imagen = ImagenGaleria.objects.get(id=kwargs['id'])
        imagen.delete()
        return redirect('listar_imagenes_galeria')