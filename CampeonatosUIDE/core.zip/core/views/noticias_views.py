from django.shortcuts import render, redirect
from django.views import View
from ..models import *
from ..forms import *
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListarNoticias(View):
    def get(self, request, *args, **kwargs):
        noticias = Noticia.objects.all()
        return render(request, 'noticia/listar.html', {'noticias': noticias})

@method_decorator(login_required, name='dispatch')
class RegistrarNoticia(View):
    def get(self, request, *args, **kwargs):
        form = NoticiaForm()
        return render(request, 'noticia/registrar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = NoticiaForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('listar_noticias')
        return render(request, 'noticia/registrar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EditarNoticia(View):
    def get(self, request, *args, **kwargs):
        noticia = Noticia.objects.get(id=kwargs['id'])
        form = NoticiaForm(instance=noticia)
        return render(request, 'noticia/editar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        noticia = Noticia.objects.get(id=kwargs['id'])
        form = NoticiaForm(request.POST, request.FILES, instance=noticia)
        if form.is_valid():
            form.save()
            return redirect('listar_noticias')
        return render(request, 'noticia/editar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EliminarNoticia(View):
    def get(self, request, *args, **kwargs):
        noticia = Noticia.objects.get(id=kwargs['id'])
        return render(request, 'noticia/eliminar.html', {'noticia': noticia})
    def post(self, request, *args, **kwargs):
        noticia = Noticia.objects.get(id=kwargs['id'])
        noticia.delete()
        return redirect('listar_noticias')