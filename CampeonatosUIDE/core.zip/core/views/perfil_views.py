from django.shortcuts import render, redirect
from ..models import Usuario
from ..forms import UsuarioForm
from django.contrib.auth.decorators import login_required

@login_required
def vista_perfil_usuario(request):
    return render(request, 'usuario/perfil.html', {'user': request.user})

@login_required
def editar_perfil(request):
    if request.method == 'POST':
        form = UsuarioForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('perfil_usuario')
    else:
        form = UsuarioForm(instance=request.user)
    return render(request, 'usuario/editar_perfil.html', {'form': form})
