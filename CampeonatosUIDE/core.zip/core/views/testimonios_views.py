from django.shortcuts import render, redirect
from django.views import View
from ..models import *
from ..forms import *
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

@method_decorator(login_required, name='dispatch')
class ListarTestimonios(View):
    def get(self, request, *args, **kwargs):
        testimonios = Testimonio.objects.all()
        return render(request, 'testimonio/listar.html', {'testimonios': testimonios})

@method_decorator(login_required, name='dispatch')
class RegistrarTestimonio(View):
    def get(self, request, *args, **kwargs):
        form = TestimonioForm()
        return render(request, 'testimonio/registrar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        form = TestimonioForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('listar_testimonios')
        return render(request, 'testimonio/registrar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EditarTestimonio(View):
    def get(self, request, *args, **kwargs):
        testimonio = Testimonio.objects.get(id=kwargs['id'])
        form = TestimonioForm(instance=testimonio)
        return render(request, 'testimonio/editar.html', {'form': form})
    def post(self, request, *args, **kwargs):
        testimonio = Testimonio.objects.get(id=kwargs['id'])
        form = TestimonioForm(request.POST, request.FILES, instance=testimonio)
        if form.is_valid():
            form.save()
            return redirect('listar_testimonios')
        return render(request, 'testimonio/editar.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class EliminarTestimonio(View):
    def get(self, request, *args, **kwargs):
        testimonio = Testimonio.objects.get(id=kwargs['id'])
        return render(request, 'testimonio/eliminar.html', {'testimonio': testimonio})
    def post(self, request, *args, **kwargs):
        testimonio = Testimonio.objects.get(id=kwargs['id'])
        testimonio.delete()
        return redirect('listar_testimonios')