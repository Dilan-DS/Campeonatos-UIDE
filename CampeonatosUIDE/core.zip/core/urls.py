from django.urls import path
from django.contrib.auth import views as auth_views
from core.views import (
    admin_views, autenticacion_views, campeonato_views, codigoqr_views, delegado_views, 
    deportes_views, equipo_views, estadisticas_views, galeria_views, inicio_views, 
    jugador_views, noticias_views, pago_views, partido_views, perfil_views, 
    suspension_views, testimonios_views, tipo_campeonato_views, transmision_views, arbitro_views
)
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Inicio público y dashboard general
    path('', inicio_views.inicio_publico, name='inicio_publico'),
    path('dashboard/', inicio_views.vista_inicio, name='vista_inicio'),

    # Dashboards por rol
    path('panel/admin/', admin_views.admin_dashboard, name='admin_dashboard'),
    path('panel/admin/crear-usuario/', admin_views.crear_usuario_admin, name='crear_usuario_admin'),
    path('panel/delegado/', delegado_views.DelegadoDashboardView.as_view(), name='delegado_dashboard'),
    path('panel/jugador/', jugador_views.jugador_dashboard, name='jugador_dashboard'),

    # Autenticación y perfil
    path('login/', autenticacion_views.vista_login, name='login'),
    path('logout/', autenticacion_views.vista_logout, name='logout'),
    path('registro/', autenticacion_views.vista_registro, name='registro'),
    path('perfil/', perfil_views.vista_perfil_usuario, name='perfil_usuario'),
    path('perfil/editar/', perfil_views.editar_perfil, name='editar_perfil'),

    # Recuperación de contraseña
    path('reset_password/', auth_views.PasswordResetView.as_view(template_name='usuario/password_reset.html'), name='password_reset'),
    path('reset_password_sent/', auth_views.PasswordResetDoneView.as_view(template_name='usuario/password_reset_sent.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='usuario/password_reset_confirm.html'), name='password_reset_confirm'),
    path('reset_password_complete/', auth_views.PasswordResetCompleteView.as_view(template_name='usuario/password_reset_complete.html'), name='password_reset_complete'),

    # Campeonatos
    path('campeonatos/', campeonato_views.ListarCampeonatos.as_view(), name='listar_campeonatos'),
    path('campeonatos/nuevo/', campeonato_views.CrearCampeonato.as_view(), name='crear_campeonato'),
    path('campeonatos/<int:id>/', campeonato_views.DetalleCampeonato.as_view(), name='detalle_campeonato'),
    path('campeonatos/<int:id>/editar/', campeonato_views.EditarCampeonato.as_view(), name='editar_campeonato'),
    path('campeonatos/<int:id>/eliminar/', campeonato_views.EliminarCampeonato.as_view(), name='eliminar_campeonato'),
    path('campeonatos/<int:id>/fixture/', campeonato_views.FixtureCampeonato.as_view(), name='fixture_campeonato'),
    path('campeonatos/<int:campeonato_id>/tabla-posiciones/', campeonato_views.TablaPosiciones.as_view(), name='tabla_posiciones'),
    path('campeonatos/<int:campeonato_id>/generar-calendario/', campeonato_views.GenerarCalendario.as_view(), name='generar_calendario'),
    path('campeonatos/publicos/', campeonato_views.CampeonatosPublicos.as_view(), name='campeonatos_publicos'),

    # Equipos
    path('equipos/', equipo_views.listar_equipos, name='listar_equipos'),
    path('equipo/nuevo/', equipo_views.registrar_equipo, name='registrar_equipo'),
    path('equipo/<int:id>/', equipo_views.detalle_equipo, name='detalle_equipo'),
    path('equipo/<int:id>/editar/', equipo_views.editar_equipo, name='editar_equipo'),
    path('equipo/<int:id>/eliminar/', equipo_views.eliminar_equipo, name='eliminar_equipo'),
    path('equipo/<int:id>/pago/', equipo_views.pago_equipo, name='pago_equipo'),
    path('equipo/<int:id>/jugadores/', equipo_views.jugadores_equipo, name='jugadores_equipo'),

    # Partidos
    path('partidos/', partido_views.listar_partidos, name='listar_partidos'),
    path('partidos/registrar/', partido_views.registrar_partido, name='registrar_partido'),
    path('partidos/<int:partido_id>/', partido_views.detalle_partido, name='detalle_partido'),
    path('partidos/calendario/', partido_views.ver_calendario_completo, name='ver_calendario_completo'),

    # Pagos
    path('delegado/pago/registrar/', delegado_views.registrar_pago, name='registrar_pago_delegado'),
    path('delegado/pago/exito/', delegado_views.pago_registrado_exitosamente, name='pago_registrado_exitosamente'),
    path('admin/pagos/pendientes/', admin_views.listar_pagos_pendientes, name='listar_pagos_pendientes'),
    path('admin/pagos/<int:pago_id>/aceptar/', admin_views.aceptar_pago, name='aceptar_pago'),
    path('admin/pagos/<int:pago_id>/rechazar/', admin_views.rechazar_pago, name='rechazar_pago'),

    # Admin
    path('admin/vista-protegida/', admin_views.vista_protegida_ejemplo, name='vista_protegida_ejemplo'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
