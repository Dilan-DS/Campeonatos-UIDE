import itertools
import random
from datetime import timedelta, datetime

from core.models import Partido, Campeonato, Equipo, Arbitro

def generate_round_robin_fixture(teams):
    # Ensure an even number of teams for round-robin
    if len(teams) % 2 != 0:
        teams.append(None)  # Add a dummy team for odd numbers

    n = len(teams)
    matches = []
    # Generate rounds
    for round_num in range(n - 1):
        for i in range(n // 2):
            team1 = teams[i]
            team2 = teams[n - 1 - i]
            if team1 and team2:  # Avoid matches with dummy team
                matches.append((team1, team2))
        # Rotate teams (except the first one)
        teams = [teams[0]] + [teams[-1]] + teams[1:-1]
    return matches

def assign_dates_and_referees(championship, teams, arbitros):
    all_matches = generate_round_robin_fixture(list(teams))
    
    # Filter available dates based on championship's allowed days
    start_date = championship.fecha_inicio
    end_date = championship.fecha_fin
    
    available_dates = []
    current_date = start_date
    while current_date <= end_date:
        if current_date.strftime('%A').upper() in championship.dias_partido:
            available_dates.append(current_date)
        current_date += timedelta(days=1)

    if not available_dates:
        raise ValueError("No hay días disponibles para partidos en el rango de fechas del campeonato.")

    # Simple time slots for now, can be made more dynamic
    time_slots = [
        datetime.strptime("10:00", "%H:%M").time(),
        datetime.strptime("12:00", "%H:%M").time(),
        datetime.strptime("14:00", "%H:%M").time(),
        datetime.strptime("16:00", "%H:%M").time(),
    ]

    generated_matches = []
    match_counter = 0
    
    for team1, team2 in all_matches:
        # Ensure both teams are valid (not dummy)
        if team1 is None or team2 is None:
            continue

        # Assign a date and time
        if match_counter >= len(available_dates) * len(time_slots):
            raise ValueError("No hay suficientes fechas/horas disponibles para todos los partidos.")
        
        date_index = (match_counter // len(time_slots)) % len(available_dates)
        time_index = match_counter % len(time_slots)
        
        match_date = available_dates[date_index]
        match_time = time_slots[time_index]

        # Randomly assign a referee
        assigned_arbitro = random.choice(arbitros) if arbitros else None

        generated_matches.append({
            'campeonato': championship,
            'equipo_local': team1,
            'equipo_visitante': team2,
            'fecha': match_date,
            'hora': match_time,
            'lugar': f"Cancha {random.randint(1, 3)}",  # Example: Random court
            'arbitro': assigned_arbitro,
            'estado': 'PROGRAMADO'
        })
        match_counter += 1
    
    return generated_matches

def create_matches_for_championship(championship_id):
    try:
        championship = Campeonato.objects.get(id=championship_id)
    except Campeonato.DoesNotExist:
        return False, "Campeonato no encontrado."

    teams = list(championship.equipos.filter(aprobado=True))
    if len(teams) < 2:
        return False, "Se necesitan al menos 2 equipos aprobados para generar el calendario."

    arbitros = list(championship.arbitros_asignables.all())
    if not arbitros:
        return False, "No hay árbitros asignados a este campeonato para generar el calendario."

    try:
        matches_data = assign_dates_and_referees(championship, teams, arbitros)
    except ValueError as e:
        return False, str(e)

    for match_data in matches_data:
        # Check if a similar match already exists to prevent duplicates
        # This is a basic check, more robust checks might be needed depending on exact requirements
        existing_match = Partido.objects.filter(
            campeonato=match_data['campeonato'],
            equipo_local=match_data['equipo_local'],
            equipo_visitante=match_data['equipo_visitante'],
            fecha=match_data['fecha'],
            hora=match_data['hora']
        ).first()

        if not existing_match:
            Partido.objects.create(**match_data)
    
    return True, "Calendario generado exitosamente."